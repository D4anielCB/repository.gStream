# -*- coding: utf-8 -*-
import xbmc
import sys, xbmcplugin, xbmcgui, xbmcaddon, os, json, hashlib, re, unicodedata, math, xbmcvfs
import shutil
from urllib.parse import urlparse, quote_plus, unquote
from urllib.request import urlopen, Request
import urllib.request, urllib.parse, urllib.error
import urllib.parse

AddonID = 'plugin.video.GayStream'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
addonDir = Addon.getAddonInfo('path')
icon = os.path.join(addonDir,"icon.png")
iconsDir = os.path.join(addonDir, "resources", "images")

libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
import xx, common

addon_data_dir = xbmcvfs.translatePath(Addon.getAddonInfo("profile"))
cacheDir = os.path.join(addon_data_dir, "cache")

if not os.path.exists(cacheDir):
	os.makedirs(cacheDir)

def Categories(): #0
	#xx.AddDir("Principal", "Main", "Main", isFolder=True)
	xx.AddDir("Canais", "", "Canais", isFolder=True)
	xx.AddDir("Categorias", "", "Categorias", isFolder=True)
	xx.AddDir("Busca", "", "Busca", isFolder=True)
	#xx.AddDir("Play", "http://gaystream.pw/video/26131/czech-hunter-578.html", "PlayUrl", isFolder=False, IsPlayable=True)
	
def Main():
	link = common.OpenURL("http://gaystream.pw/")
	ST(link)
	
def Categorias():
	link = common.OpenURL("https://gaystream.pw/categories")
	#return
	entries = re.findall('category\/([^\"]+).{1,50}title..([^\"]+).{50,100}img.{1,10}src..([^\"]+)', link)
	for id,titulo,img in entries:
		img2 = b64toimg(img,id)
		xx.AddDir(unquote(titulo).replace("View ",""), "category/"+id, "Video", img2, img2, isFolder=True)
	
def Canais():
	link = common.OpenURL("https://gaystream.pw/channels")
	#return
	#entries = re.findall('channel\/([^\"]+).{100,200}img.{1,10}src..([^\"]+)', link)
	entries = re.findall('channel\/([^\"]+).{1,50}title..([^\"]+).{50,100}img.{1,10}src..([^\"]+)', link)
	for id,titulo,img in entries:
		img2 = b64toimg(img,id)
		xx.AddDir(unquote(titulo).replace("View ",""), "channel/"+id, "Video", img2, img2, isFolder=True)

def setBusca():
	q = xbmcgui.Dialog().input("Busca:")
	Addon.setSetting("setBusca", q )
	Addon.setSetting("cBusca", "0" )
	xbmc.executebuiltin("Container.Refresh()")	
def Busca():
	q = Addon.getSetting("setBusca")
	xx.AddDir("Busca: "+q, "setBusca", "setBusca", "", "", isFolder=False)
	cPageurl = "cBusca"
	cPage = "0" if Addon.getSetting(cPageurl) == "" else Addon.getSetting(cPageurl) 
	if int(cPage) > 0:
		xx.AddDir("[COLOR blue][B]<< Pagina Anterior ["+ str( int(cPage) ) +"[/B]][/COLOR]", cPage , "xx.PaginacaoMenos" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Previous-icon.png", isFolder=False, dados={'page': cPageurl})
	xx.AddDir("[COLOR blue][B]Proxima Pagina >>  ["+ str( int(cPage) + 1 ) +"[/B]][/COLOR]", cPage , "xx.PaginacaoMais" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Next-2-2-icon.png", isFolder=False, dados={'page': cPageurl})
	page = str( int(cPage) + 1 )
	link = common.OpenURL("https://gaystream.pw/page/"+page+"?s="+quote_plus(q))
	entries = re.findall('video\/([^\/]+).{10,200}title..([^\"]+).{100,200}img.{1,10}src..([^\"]+)', link)
	for id,titulo,img in entries:
		img2 = b64toimg(img,id)
		xx.AddDir(unquote(titulo).replace("&amp;","&"), id, "PlayUrl", img2, img2, isFolder=False, IsPlayable=True)
	xx.AddDir("[COLOR blue][B]Proxima Pagina >>  ["+ str( int(cPage) + 1 ) +"[/B]][/COLOR]", cPage , "xx.PaginacaoMais" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Next-2-2-icon.png", isFolder=False, dados={'page': cPageurl})
	
def Video():
	cPageurl = url.split("/")[0]+"."+url.split("/")[1]
	cPage = "0" if Addon.getSetting(cPageurl) == "" else Addon.getSetting(cPageurl) 
	if int(cPage) > 0:
		xx.AddDir("[COLOR blue][B]<< Pagina Anterior ["+ str( int(cPage) ) +"[/B]][/COLOR]", cPage , "xx.PaginacaoMenos" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Previous-icon.png", isFolder=False, dados={'page': cPageurl})
	xx.AddDir("[COLOR blue][B]Proxima Pagina >>  ["+ str( int(cPage) + 1 ) +"[/B]][/COLOR]", cPage , "xx.PaginacaoMais" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Next-2-2-icon.png", isFolder=False, dados={'page': cPageurl})
	page = str( int(cPage) + 1 )
	#ST(page)
	#return
	link = common.OpenURL("http://gaystream.pw/video/"+url+"/page/"+page)
	entries = re.findall('video\/([^\/]+).{10,200}title..([^\"]+).{100,200}img.{1,10}src..([^\"]+)', link)
	for id,titulo,img in entries:
		img2 = b64toimg(img,id)
		xx.AddDir(unquote(titulo).replace("&amp;","&"), id, "PlayUrl", img2, img2, isFolder=False, IsPlayable=True)
	xx.AddDir("[COLOR blue][B]Proxima Pagina >>  ["+ str( int(cPage) + 1 ) +"[/B]][/COLOR]", cPage , "xx.PaginacaoMais" ,"http://icons.iconarchive.com/icons/iconsmind/outline/256/Next-2-2-icon.png", isFolder=False, dados={'page': cPageurl})
		
def b64toimg(code="",file="01"):
	import base64
	file = os.path.join(cacheDir,file+".jpg")
	#return cacheDir
	coded_data = re.sub('data.{1,20}base64,', '', code )
	decoded_data = base64.b64decode(coded_data)
	with open(file, "wb") as f:
		f.write(decoded_data)
		f.close()
	return file
	
	
def RetLink(elo): ############
	try:
		import requests
		url = 'https://www.watchgayporn.online/api/source/'+elo
		head = {'Referer': 'https://www.watchgayporn.online/','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/1/10', 'Accept-Encoding': 'identity', 'Content-Type': 'application/x-www-form-urlencoded', 'DNT': '1'}
		resp = requests.post('https://www.watchgayporn.online/api/source/'+elo, data = {}, headers=head)
		return resp.text.replace("\n", '\r\n')
	except:
		return "erro"	

def PlayUrl():
	#m3u = os.path.join(addonDir,"playlist.m3u8")
	#xx.PlayUrl("",m3u)
	#ST(m3u)
	#return
	q = "http://gaystream.pw/video/"+url
	link = common.OpenURL(q)
	iframe = re.findall('https?:\/\/www.watchgayporn.online[^\"]+', link)
	id = iframe[0].split("/v/")
	mp4 = RetLink(id[1])
	mp4j = json.loads(mp4)
	data1=[]
	data2=[]
	mp4j = list(reversed(mp4j['data']))
	for entry in mp4j:
		data1.append(entry["label"])
		data2.append(entry["file"])
	d = xbmcgui.Dialog().select("Escolha a resolução:", data1)
	if d >-1 :
		xx.PlayUrl("",data2[d]+"|Referer=https://watchgayporn.online")

	
params = urllib.parse.parse_qs(sys.argv[2][1:]) 
name = params.get('name',[None])[0]
url = params.get('url',[None])[0]
mode = params.get('mode',[None])[0]
iconimage = params.get('iconimage',[None])[0]
logos = params.get('logos',[None])[0]
info = params.get('info',[None])[0]
dados = params.get('dados',[{}])[0]
#----------------------------------------
def ST(x="", o="w"):
	if o == "1":
		o = "a+"
	if type(x) == type({}) or type(x) == type([]):
		y = json.dumps(x, indent=4, ensure_ascii=True)
	else:
		y = str(str(x).encode("utf-8"))
	Path = xbmc.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
	py = os.path.join( Path, "study.txt")
	file = open(py, o)
	file.write(y+"\n"+str(type(x)))
	file.close()

if mode == None:
	Categories()
	xx.setViewM()
elif mode == "Main":
	Main()
elif mode == "Canais":
	Canais()
	xx.setViewM()
elif mode == "Categorias":
	Categorias()
	xx.setViewM()
elif mode == "setBusca":
	setBusca()
	xx.setViewM()
elif mode == "Busca":
	Busca()
	xx.setViewM()
elif mode == "Video":
	Video()
	xx.setViewM()
#-------------------------------
elif mode == "PlayUrl":
	PlayUrl()
#-------------------------------
elif mode == "xx.PaginacaoMenos":
	xx.PaginacaoMenos()
elif mode == "xx.PaginacaoMais":
	xx.PaginacaoMais()
#-------------------------------
elif mode == "Reload":
	xbmc.executebuiltin("Container.Refresh()")
#-------------------------------
xbmcplugin.endOfDirectory(int(sys.argv[1]))